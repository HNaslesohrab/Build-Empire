import { supabase } from "@/lib/supabase";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const clan = req.nextUrl.searchParams.get("clan") || "none";
  const body = await req.json();
  const fid = body.untrustedData.fid;

  const { data: existing } = await supabase
    .from("players")
    .select("*")
    .eq("fid", fid)
    .single();

  let imageUrl = \`https://yourdomain.com/images/\${clan}.jpg\`;
  let message = "";

  if (existing) {
    imageUrl = \`https://yourdomain.com/images/\${existing.clan}.jpg\`;
    message = \`You are already in the \${existing.clan.charAt(0).toUpperCase() + existing.clan.slice(1)} Clan.\`;
  } else {
    await supabase.from("players").insert({ fid, clan });
    message = \`Welcome to the \${clan.charAt(0).toUpperCase() + clan.slice(1)} Clan!\`;
  }

  return new NextResponse(\`
    <html>
      <head>
        <meta property="fc:frame" content="vNext" />
        <meta property="fc:frame:image" content="\${imageUrl}" />
        <meta property="og:description" content="\${message}" />
      </head>
    </html>
  \`, {
    headers: {
      'Content-Type': 'text/html'
    }
  });
}
